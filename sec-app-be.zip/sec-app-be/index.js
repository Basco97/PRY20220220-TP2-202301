var express = require('express');
var mysql = require('mysql');
var cors = require ('cors')

var app = express();
app.use(express.json())
app.use(cors());

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'password',
  database : 'answers'
});
connection.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + connection.threadId);
});


app.post('/', function(req, res) {
    let ps = req.body
    connection.query('INSERT INTO answers SET ?', ps, function (error, results) {
      if (error) throw error;
      console.log('The solution is: ', results);
      res.status(200).send({});
    });
});

app.get('/', function(req, res) {
  if (req.body > 0){
    connection.query('SELECT * FROM answers WHERE `email` = ?', [req.body], function (error, results) {
      if (error) throw error;
      console.log('The solution is: ', results);
      res.send(results);
    });
  }else
    connection.query('SELECT * FROM answers', function (error, results) {
      if (error) throw error;
      console.log('The solution is: ', results);
      res.send(results);
    });
});

app.listen(3000, function() {
  console.log('Aplicación ejemplo, escuchando el puerto 3000!');
});